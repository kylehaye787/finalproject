﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class StartingScreen : Form
    {
        public StartingScreen()
        {
            InitializeComponent();
            StartscreenLoop();
            Publicvariable();
        }

        public void Publicvariable()
        {
            var PlayerName = "Bob"; // The players in-game name <Default: Bob>
            var PlayerClass = new string[] {"Human", "Dwarf", "Highlander", "Warper" }; // The race they <Default: Human>
            var PlayerHP = 100; // The players health <Default: 100>
            var PlayerDef = 0; // The players resistence modifiers
            var PlayerAtk = 0; // The players attack modifiers

            string[] PlayerGear = new string[] { "Brawler", "Marksman", "Caster", "Glitch", "Thief", "Hitokiri" }; // Player starting gear
            string[] Skills = new string[] {"", "", "", "", "", ""}; // Player skills and modifiers
            var DebugMode = false; // Activate debugging mode
            bool[] StatusEffect = {false, false, false, false, false}; // 0 = Bleeding, 1 = Burning, 2 = Freezing, 3 = Drained, 4 = Stunned

            int GameEventInt;
        }

        public void StartscreenLoop()
        {
            Boolean SpacebarPressed;
            if (Keys.Space = true)
            {

            }
        }

        private void gameLoop_Tick(object sender, EventArgs e)
        {

        }

            private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void StartingScreen_Load(object sender, EventArgs e)
        {

        }

        private void StartingScreen_Paint(object sender, PaintEventArgs e)
        {
            //Text to draw

            string textToDraw = ".";

            //Create graphic object for form

            Graphics gs = this.CreateGraphics();

            //Create brush object

            Brush br = new SolidBrush(Color.BlueViolet);

            //Create font object

            Font f = new Font("Courier New", 20);

            //Create point object

            PointF pf = new PointF(30, 100);

            PointF pf1 = new PointF(30, 140);

            // Draws to form

            gs.DrawString(textToDraw, f, br, pf);

            gs.DrawString(textToDraw, f, br, pf1);
        }
        public void StartingScreen_KeyPress(object sender, KeyPressEventArgs space)
        {
            switch (space.KeyCode)
            {
                case Keys.Space:
                    bool SpacebarPressed = true;
                    break;
            }
        }
    }
}
